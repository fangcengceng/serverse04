//
//  LeftViewController.m
//  侧滑练习
//
//  Created by codygao on 16/8/14.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "LeftViewController.h"
#import "RESideMenu.h"
@interface LeftViewController()

@end
@implementation LeftViewController
-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor yellowColor];
    
}
@end
