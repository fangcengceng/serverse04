//
//  ContainerViewController.m
//  侧滑练习
//
//  Created by codygao on 16/8/14.
//  Copyright © 2016年 HM. All rights reserved.
//

#import "ContainerViewController.h"

@implementation ContainerViewController
-(void)viewDidLoad{
    self.view.backgroundColor = [UIColor redColor];
}
@end
